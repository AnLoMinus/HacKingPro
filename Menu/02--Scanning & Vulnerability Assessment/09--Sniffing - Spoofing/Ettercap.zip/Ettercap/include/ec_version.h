#ifndef ETTERCAP_VERS_H
#define ETTERCAP_VERS_H

#define EC_VERSION            "0.8.4-rc"
#define EC_VERSION_MAJOR       0
#define EC_VERSION_MINOR       8
#define EC_VERSION_REVISION    4
#define EC_VERSION_SUBREVISION 0
#ifndef PROGRAM
   #define PROGRAM            "ettercap"
#endif
#define EC_COPYRIGHT          "2001-2020"
#define EC_AUTHORS            "Ettercap Development Team"

#endif

/* EOF */

