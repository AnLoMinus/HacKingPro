#ifndef ETTERCAP_MANUF_H
#define ETTERCAP_MANUF_H

EC_API_EXTERN int manuf_init(void);
EC_API_EXTERN char * manuf_search(const char *m);

#endif

/* EOF */

// vim:ts=3:expandtab

