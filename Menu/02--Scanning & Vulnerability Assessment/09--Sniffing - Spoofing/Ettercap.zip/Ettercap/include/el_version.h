#ifndef ETTERLOG_VERSION_H
#define ETTERLOG_VERSION_H

#define PROGRAM      "etterlog"

#endif

/* EOF */

