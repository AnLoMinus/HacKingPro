#ifndef ETTERCAP_HTTP_H
#define ETTERCAP_HTTP_H

EC_API_EXTERN int http_fields_init(void);

#endif

/* EOF */

// vim:ts=3:expandtab

