export type Ipv4TcpCacheState = {
	ip: string | number;
	port: string | number;
	file_name?: string | number;
};
