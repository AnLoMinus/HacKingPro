export type ObfuscatedFile = {
	name: string;
	input: string;
};
