# blue-team

Blue Team Scripts

* Tested on Debian 9

