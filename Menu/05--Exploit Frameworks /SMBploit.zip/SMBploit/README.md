# SMBploit

Offensive tool to `scan & exploit` vulnerabilities in `Microsoft Windows` over the `Samba protocol (SMB) SMBv1/SMBv2` using the `Metasploit Framework`

* [MS08-067](https://www.rapid7.com/db/modules/exploit/windows/smb/ms08_067_netapi/) **Rapid7 | Brett Moore | Frank2 | Jduck | hdm**
* [MS17-010](https://github.com/Telefonica/Eternalblue-Doublepulsar-Metasploit) **Telefónica | Pablo Gonzalez (@pablogonzalezpe) | Sheila A. Berta (@UnaPibaGeek)**

# ONLY USE FOR EDUCATIONAL PURPOSES

* Screenshot


![](/screenshot/screenshot2.png)

* Install

```cmd
root@kali:~# cd ~
root@kali:~# git clone https://github.com/d4t4s3c/SMBploit.git
root@kali:~# cd SMBploit
root@kali:~# chmod +x *.sh
root@kali:~# ./install.sh
root@kali:~# ./SMBploit.sh
```

* Tested On

  * Kali
  * Parrot
  
* Requirements:
   * Metasploit
   * Xterm
   * Wine

# NOT BE BAD


