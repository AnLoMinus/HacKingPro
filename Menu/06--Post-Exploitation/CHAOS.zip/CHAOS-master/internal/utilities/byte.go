package utilities

func ByteToString(value []byte) string {
	return string(value)
}

func StringToByte(value string) []byte {
	return []byte(value)
}
