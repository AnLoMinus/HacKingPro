"""Print working directory

SYNOPSIS:
    is-valid

DESCRIPTION:
    test plugin

AUTHOR:
    nil0x42 <http://goo.gl/kb2wf>
"""

# this fails with python3
print ""
