# Functional Tests: core

This 'miscellaneous' test category is intended to test
internal framework funcionalities related to general
behavior, and cannot be clearly identified by another test
category.
