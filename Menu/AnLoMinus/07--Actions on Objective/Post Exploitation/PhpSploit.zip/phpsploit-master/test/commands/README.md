# Functional Tests: commands

Test all `Core Commands` of phpsploit.
Core commands can be identified in `ui/interface.py`. Each one
is implemented as a `'do_' + <COMMAND-NAME>` method.

Core commands can be listed with `phpsploit -e help`.
