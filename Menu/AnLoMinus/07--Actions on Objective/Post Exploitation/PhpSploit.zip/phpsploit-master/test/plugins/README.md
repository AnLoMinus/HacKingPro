# Functional Tests: plugins

Test all `Plugins` of phpsploit.
Plugins commands are available within the UI as soon
as phpsploit is connected to a remote target.

Built-in plugins can be identified in `plugins/` directory,
and can be listed with `phpsploit -e help` (if connected to remote TARGET).
