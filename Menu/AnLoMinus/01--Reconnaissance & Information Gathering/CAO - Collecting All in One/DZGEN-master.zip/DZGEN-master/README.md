##  ★  🏗 DZGEN V1.0 ✔️ | <img src="https://img.shields.io/badge/i-DZGEN-green.svg">
[![Version](https://img.shields.io/badge/DZGEN-v1.0-brightgreen.svg?maxAge=259200)]()
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Ubuntu,Kali,Mint,Parrot-blue.svg)]()
[![AUR](https://img.shields.io/aur/license/yaourt.svg)]()

Author: joker-security [ dev-labs ]

## ★ Description:

this tool is working with kali linux tools scan port , Brute force protocol Service ,scan website , exploit system , exploit sql injection website and also have other characteristics

## ★ How To Use:

1? - Download the tool from github

git clone https://github.com/joker25000/DZGEN

2? - The installation the tool

cd DZGEN

chmod +x DZGEN

./DZGEN

3 ?- Run DZGEN tool in terminal

DZGEN 

## ★ Screenshot:

<img src="https://i.imgur.com/Dk8ZLHt.png" width="23%"></img> <img src="https://i.imgur.com/ljm10ic.png" width="23%"></img> <img src="https://i.imgur.com/fSAES7q.png" width="23%"></img> <img src="https://i.imgur.com/Ym7aKFt.png" width="23%"></img> <img src="https://i.imgur.com/hvnISw2.png" width="23%"></img> <img src="https://i.imgur.com/axqaMyh.png" width="23%"></img> <img src="https://i.imgur.com/DVJAbJu.png" width="23%"></img> <img src="https://i.imgur.com/k6SzRKc.png" width="23%"></img> <img src="https://i.imgur.com/tf1qedL.png" width="23%"></img> <img src="https://i.imgur.com/5ccKNTc.png" width="23%"></img> <img src="https://i.imgur.com/koUZYHr.png" width="23%"></img> <img src="https://i.imgur.com/t0t3fym.png" width="23%"></img> 

## ★ video tutorial:

[![ DZGEN - Works with Kali Linux tools ](https://i.ytimg.com/vi/dAgB3PI75IQ/hqdefault.jpg)](https://www.youtube.com/watch?v=dAgB3PI75IQ&t=6s)

## ★ About:

● TWITTER : https://twitter.com/SecurityJoker

● YOUTUBE : https://www.youtube.com/c/Professionalhacker25

● FACE Pg : https://facebook.com/kali.linux.pentesting.tutorials

● Tested On : Parrot Os / KALI-LINUX / lxle-Linux
