red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
clear
echo ""
echo ""
echo -e "$pink          ╔═════════════════════════════════════╗"
echo -e "$pink          ║         $grn   H-INFECT$red TOOL $pink           ║"
echo -e "$pink          ║   $red     IS$grn UP-TO-DATE.$red THERE IS   $pink   ║"
echo -e "$pink          ║      $grn  NO UPDATE$red ARE AVAILABLE    $pink  ║"
echo -e "$pink          ╚═════════════════════════════════════╝"
echo ""
sleep 3.0
echo -e "$ylo Press Enter"
read e1