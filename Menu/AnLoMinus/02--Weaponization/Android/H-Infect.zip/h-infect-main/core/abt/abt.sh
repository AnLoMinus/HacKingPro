red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
clear
echo -e "$blue                    
	_  _ _   _    _  _ ____ _  _ ____    _ ____ 
	|\/|  \_/     |\ | |__| |\/| |___    | [__  
	|  |   |      | \| |  | |  | |___    | ___]
	"
echo ""
sleep 2.0
clear
echo -e "
$red ▒█ ▒█ ▒█▀▀▀ ▀▀█▀▀ 　 ▒█▀▀█  █▀▀█ ▒█▄ ▒█ ▒█▀▀▄ ▒█ ▒█ ▀█▀ 
$ylo ▒█▀▀█ ▒█▀▀▀  ▒█   　 ▒█ ▄▄ ▒█▄▄█ ▒█▒█▒█ ▒█ ▒█ ▒█▀▀█ ▒█  
$cyan ▒█ ▒█ ▒█▄▄▄  ▒█   　 ▒█▄▄█ ▒█ ▒█ ▒█  ▀█ ▒█▄▄▀ ▒█ ▒█ ▄█▄
"
sleep 4.0
echo -e "$blue                      ╔═══════════╗"
echo -e "$blue                      ║👉$grn About 👈$blue║"
echo -e "$blue ╔══════════════════════════════════════════════════════╗"
echo -e "$blue ║  $grn          🙏 hey, my name is$red Het Gandhi.           $blue ║"
echo -e "$blue ║  $grn        My purpose creates this$red tool$grn easily        $blue ║"
echo -e "$blue ║  $grn      $red  creates$grn the$red virus$grn in a$red few seconds.        $blue ║"
echo -e "$blue ║  $grn     I$red designed$grn this$red tool$grn as an easy way only,     $blue ║"
echo -e "$blue ║  $grn      you can$red install$grn it in$red Termux,$grn easily.        $blue ║"
echo -e "$blue ║  $grn             I hope guys$red liked$grn it.😘               $blue ║"
echo -e "$blue ╚══════════════════════════════════════════════════════╝"
echo ""
echo -e "         $ylo       YOUR FRIEND :-$cyan Het Gandhi$rset"
echo ""
echo ""
sleep 10.0
echo -e "$pink Press Enter $rset"
sleep 2.0
read a1