#colour section
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
#script coding starts
clear
echo "  "
echo " "
echo -e "$red                H$blue -$red INFECT$ylo IS RUNNING...$rset"
echo "  "
echo -e "$pink    [[[$cyan THIS MAY TAKE TIME UPTO$ylo 2 MINUTES$cyan SO WAIT$pink ]]]$rset"
echo " "
sleep 3.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#................................................]$grn 2%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##...............................................]$grn 4%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###..............................................]$grn 6%"
sleep 5.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[####.............................................]$grn 8%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#####............................................]$grn 10%"
sleep 3.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[######...........................................]$grn 12%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#######..........................................]$grn 14%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[########.........................................]$grn 16%"
sleep 5.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#########........................................]$grn 18%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##########.......................................]$grn 20%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###########......................................]$grn 22%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[############.....................................]$grn 24%"
sleep 5.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#############....................................]$grn 26%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##############...................................]$grn 28%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###############..................................]$grn 30%"
sleep 2.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[################.................................]$grn 32%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#################................................]$grn 34%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##################...............................]$grn 36%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###################..............................]$grn 38%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[####################.............................]$grn 40%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#####################............................]$grn 42%"
sleep 2.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[######################...........................]$grn 44%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#######################..........................]$grn 46%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[########################.........................]$grn 48%"
sleep 5.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#########################........................]$grn 50%"
sleep 5.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##########################.......................]$grn 52%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###########################......................]$grn 54%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[############################.....................]$grn 56%"
sleep 3.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#############################....................]$grn 58%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##############################...................]$grn 60%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###############################..................]$grn 62%"
sleep 4.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[################################.................]$grn 64%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#################################................]$grn 66%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##################################...............]$grn 68%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###################################..............]$grn 70%"
sleep 5.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[####################################.............]$grn 72%"
sleep 2.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#####################################............]$grn 74%"
sleep 0.1
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[######################################...........]$grn 76%"
sleep 0.1
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#######################################..........]$grn 78%"
sleep 0.1
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[########################################.........]$grn 80%"
sleep 0.1
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#########################################........]$grn 82%"
sleep 0.1
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##########################################.......]$grn 84%"
sleep 6.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###########################################......]$grn 86%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[############################################.....]$grn 88%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[#############################################....]$grn 90%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[##############################################...]$grn 92%"
sleep 3.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[###############################################..]$grn 94%"
sleep 0.3
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[################################################.]$grn 96%"
sleep 2.0
clear
echo -e "$blue Process$grn :-"
echo -e "\033[1;34m [\033[1;32m*\033[1;34m]$red[################################################]$grn 100%"
sleep 6.0
clear
echo ""
echo ""
echo -e "$grn              All are Good Lunching the TOOL"
sleep 4.0
clear
bash not.sh