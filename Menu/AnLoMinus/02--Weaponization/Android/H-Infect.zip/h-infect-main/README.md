# H-INFECT

<p align="center">
<img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge">

  
## ABOUT
  
H-INFECT is a officially made for HACKING users of TERMUX from this tool in just one click you can CREATE VIRUS. This tool works on rooted Android device, Non-rooted Android device FOR ANDROID DEVICES 27 TYPES OF VIRUS, FOR WINDOWS 11 TYPES OF VIRUS AND MACOS 2 TYPES of virus

## SCREENSHOT  

![h-infect](https://user-images.githubusercontent.com/67777622/160859871-0ddc8e13-6983-4db8-a542-94d29226565b.png)
  

## AVAILABLE ON :

* Termux

## TESTED ON :

* Termux

## REQUIREMENTS :
* internet 100 MB
* external storage permission
* storage 150 MB
* 1gb ram
  
## FEATURES :
* [+] Easy For Beginners
* [+] Android Virus
* [+] Windows Virus
* [+] Macos Virus
* [+] One Click Virus Created  
* [+] FIxed Issue
  
  
## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
