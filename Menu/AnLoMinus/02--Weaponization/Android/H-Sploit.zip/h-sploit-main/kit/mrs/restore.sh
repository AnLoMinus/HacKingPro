#colour section
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
#script coding starts
clear
echo "  "
echo '
	    ____     ______   _______________  ____  ______
	   / __ \   / ____/  / ___/_  __/ __ \/ __ \/ ____/
	  / /_/ /  / __/     \__ \ / / / / / / /_/ / __/   
	 / _, _/  / /___    ___/ // / / /_/ / _, _/ /___   
	/_/ |_|  /_____/   /____//_/  \____/_/ |_/_____/   
													   ' | lolcat
echo " "
echo " "
echo -e "$red         Are you sure? Press$grn ENTER$red to continue$rset"
read e4
clear
echo " "
echo " "
echo -e "$red                 METASPLOIT IS RESTORING...$rset"
echo "  "
echo -e "$grn        [THIS MAY TAKE TIME UPTO 30 MINUTES SO WAIT]$rset"
echo " "
echo -e "$red     Note:-$ylo Make sure you have backed up metasploit  
            if not then please backup it first or 
            else this script wont work$rset"
echo " "
sleep 5.0
clear
echo -e "$blue Process"
echo -e "$red [#.................................................]$grn 2%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [##................................................]$grn 4%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [###...............................................]$grn 6%"
sleep 5.0
clear
echo -e "$blue Process"
echo -e "$red [####..............................................]$grn 8%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [#####.............................................]$grn 10%"
sleep 3.0
clear
echo -e "$blue Process"
echo -e "$red [######............................................]$grn 12%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [#######...........................................]$grn 14%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [########..........................................]$grn 16%"
sleep 5.0
clear
echo -e "$blue Process"
echo -e "$red [#########.........................................]$grn 18%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [##########........................................]$grn 20%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [###########.......................................]$grn 22%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [############......................................]$grn 24%"
sleep 5.0
clear
echo -e "$blue Process"
echo -e "$red [#############.....................................]$grn 26%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [##############....................................]$grn 28%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [###############...................................]$grn 30%"
sleep 2.0
clear
echo -e "$blue Process"
echo -e "$red [################..................................]$grn 32%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [#################.................................]$grn 34%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [##################................................]$grn 36%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [###################...............................]$grn 38%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [####################..............................]$grn 40%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [#####################.............................]$grn 42%"
sleep 2.0
clear
echo -e "$blue Process"
echo -e "$red [######################............................]$grn 44%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [#######################...........................]$grn 46%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [########################..........................]$grn 48%"
sleep 5.0
clear
echo -e "$blue Process"
echo -e "$red [#########################.........................]$grn 50%"
sleep 5.0
clear
echo -e "$blue Process"
echo -e "$red [##########################........................]$grn 52%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [###########################.......................]$grn 54%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [############################......................]$grn 56%"
sleep 3.0
clear
echo -e "$blue Process"
echo -e "$red [#############################.....................]$grn 58%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [##############################....................]$grn 60%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [###############################...................]$grn 62%"
sleep 4.0
clear
echo -e "$blue Process"
echo -e "$red [################################..................]$grn 64%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [#################################.................]$grn 66%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [##################################................]$grn 68%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [###################################...............]$grn 70%"
sleep 5.0
clear
echo -e "$blue Process"
echo -e "$red [####################################..............]$grn 72%"
sleep 2.0
clear
echo -e "$blue Process"
echo -e "$red [#####################################.............]$grn 74%"
sleep 0.1
clear
echo -e "$blue Process"
echo -e "$red [######################################............]$grn 76%"
sleep 0.1
clear
echo -e "$blue Process"
echo -e "$red [#######################################...........]$grn 78%"
sleep 0.1
clear
echo -e "$blue Process"
echo -e "$red [########################################..........]$grn 80%"
sleep 0.1
clear
echo -e "$blue Process"
echo -e "$red [#########################################.........]$grn 82%"
sleep 0.1
clear
echo -e "$blue Process"
echo -e "$red [##########################################........]$grn 84%"
sleep 6.0
clear
echo -e "$blue Process"
echo -e "$red [###########################################.......]$grn 86%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [############################################......]$grn 88%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [#############################################.....]$grn 90%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [##############################################....]$grn 92%"
sleep 3.0
clear
echo -e "$blue Process"
echo -e "$red [###############################################...]$grn 94%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [################################################..]$grn 96%"
sleep 2.0
clear
echo -e "$blue Process"
echo -e "$red [#################################################.]$grn 98%"
sleep 0.3
clear
echo -e "$blue Process"
echo -e "$red [##################################################]$grn 100%"
sleep 6.0
clear
echo " "
echo " "
cd $HOME
if [ -d $HOME/metasploit-framework ]; then
echo -e "$ylo             Metasploit is Already present in termux...!$rset"
echo " "
echo -e "$red      No need to restore it if you still want to restore it
              then remove metasploit first from termux$rset"
else
clear
echo " "
echo -e "$ylo             METASPLOIT IS RESTORING PLEASE WAIT...$rset"
echo " "
echo " "
sleep 3.0
cd $HOME
rm -rf mbackup
termux-setup-storage
cd /sdcard
cp -r mbackup $HOME
cd mbackup
mv metasploit-framework $HOME
cd metasploit-framework
cd bcp
bash bcp.sh
clear
echo " "
echo " "
echo -e "$grn            [$red If you are seeing this message then you 
                  dont have a backup to restore or 
                  some internet connection problem $grn]$rset"
fi
echo " "
echo " "