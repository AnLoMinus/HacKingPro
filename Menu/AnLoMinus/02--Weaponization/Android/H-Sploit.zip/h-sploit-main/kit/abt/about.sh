red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'

clear
echo -e "$blue                    
    _  _ _   _    _  _ ____ _  _ ____    _ ____ 
    |\/|  \_/     |\ | |__| |\/| |___    | [__  
    |  |   |      | \| |  | |  | |___    | ___] 
                                                "
echo " "
sleep 4.0
clear

echo -e "

$red ▒█░▒█ ▒█▀▀▀ ▀▀█▀▀ 　 ▒█▀▀█ ░█▀▀█ ▒█▄░▒█ ▒█▀▀▄ ▒█░▒█ ▀█▀ 
$ylo ▒█▀▀█ ▒█▀▀▀ ░▒█░░ 　 ▒█░▄▄ ▒█▄▄█ ▒█▒█▒█ ▒█░▒█ ▒█▀▀█ ▒█░ 
$cyan ▒█░▒█ ▒█▄▄▄ ░▒█░░ 　 ▒█▄▄█ ▒█░▒█ ▒█░░▀█ ▒█▄▄▀ ▒█░▒█ ▄█▄
"
sleep 7.0

echo -e "$blue                             About"
echo " "
echo -e "$grn
          🙏 Hey, there I am Het Gandhi i made this tool
         to make the installation of package and some tool 
            in termux become easy by this auto script
                you can install in termux easyli, 
                       so i hope guys you
                          liked it. 😘 "
echo ""
echo -e "         $ylo         your friend :-$pink Het Gandhi$rset "
echo " "
echo ""
echo -e "$pink Press Enter $rset"
sleep 2.0
read a1