#option1
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
#coding section starts :)
clear
echo " "
echo " "
echo -e "$red
		 █ █ ▄▄ █▀ █▀█ █   █▀█ █ ▀█▀
		 █▀█    ▄█ █▀▀ █▄▄ █▄█ █  █ "
echo " "                                                          
echo " "
echo -e "$grn           >>>>$blue [$ylo click ENTER to continue$blue ]$grn <<<<$rset"
read e1
clear
echo " "
echo " "
echo -e "$cyan    》h-sploit is a official tool made for metasploit《$rset"
echo " "
echo -e "$red            [NOTE:- NEED INTERNET CONNECTION]$rset"
echo " "
echo " "
sleep 3.0
clear
echo " "
echo -e "$grn 	 ＞＞＞＞＞＞＞＞＞＞$ylo [OPTIONS]$grn ＜＜＜＜＜＜＜＜＜＜＜$rset"
echo -e "$grn 	 ##                                                 ##"
echo -e "$grn 	 ##                                                 ##"
echo -e "$grn 	 ##              ➡$red [1]$blue Metasploit install$grn           ##"
echo -e "$grn 	 ##              ➡$red [2]$blue Metasploit repair$grn            ##"
echo -e "$grn 	 ##              ➡$red [3]$blue Metasploit backup$grn            ##"
echo -e "$grn 	 ##              ➡$red [4]$blue Metasploit restore$grn           ##"
echo -e "$grn 	 ##              ➡$red [5]$blue Metasploit delete$grn            ##"
echo -e "$grn 	 ##              ➡$red [6]$blue About$grn                        ##"
echo -e "$grn 	 ##              ➡$red [7]$blue YOUTUBE$grn                      ##"
echo -e "$grn 	 ##              ➡$red [8]$blue INSTAGRAM$grn                    ##"
echo -e "$grn 	 ##              ➡$red [9]$blue GITHUB$grn                       ##"
echo -e "$grn 	 ##              ➡$red [0]$blue Exit$grn                         ##"
echo -e "$grn 	 ##                                                 ##"
echo -e "$grn 	 ##                                                 ##"
echo -e "$grn 	 ＞＞＞＞＞＞＞＞＞＞$ylo [SELECT]$grn ＜＜＜＜＜＜＜＜＜＜＜＜$rset"
echo " "
echo -e "$cyan                       [[[$ylo Select any option$cyan]]]$rset"
echo " "
read n
case "$n" in
1)echo " "
cd 
cd h-sploit
cd kit
cd hms
bash mi.sh
;;
2)echo " "
cd
cd h-sploit
cd kit
cd hms
bash mp.sh
;;
3)echo " "
cd
cd h-sploit
cd kit
cd hms
bash mb.sh
;;
4)echo " "
cd
cd h-sploit
cd kit
cd hms
bash ms.sh
;;
5)echo " "
cd
cd h-sploit
cd kit
cd hms
bash md.sh
;;
6)echo " "
cd
cd h-sploit
cd kit
cd hms
bash ma.sh
;;
7)echo " "
cd
cd h-sploit
cd kit
cd hms
bash my.sh
;;
8)echo " "
cd
cd h-sploit
cd kit
cd hms
bash mf.sh
;;
9)echo " "
cd
cd h-sploit
cd kit
cd hms
bash mg.sh
;;
0)
clear
echo " "
echo " "
echo -e "$grn
		____  _  _  ____    ____  _  _  ____ 
		(  _ \( \/ )( ___)  (  _ \( \/ )( ___)
		) _ < \  /  )__)    ) _ < \  /  )__) 
		(____/ (__) (____)  (____/ (__) (____)...$cyan have a awesome day$rset"
sleep 2.0
echo " "
echo " "
exit 
;;
*) clear
echo -e "$blue sorry, the  option you looking is not found"
sleep 2.0
clear
esac
clear 
exit 