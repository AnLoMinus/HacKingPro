# H-SPLOIT

<p align="center">
<img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge">

![wallpaperflare com_wallpaper](https://user-images.githubusercontent.com/67777622/125593635-eab289be-2e0d-47d3-b9ad-f96a36ef1729.jpg)  
  
## ABOUT
  
H-SPLOIT is a bash based script which is officially made for METASPLOIT users of termux from this tool in just one click you can INSTALL METASPLOIT, REPAIR METASPLOIT, RESTORE METASPLOIT, DELETE METASPLOIT, and lot more. This tool works on both rooted Android device and Non-rooted Android device.

## SCREENSHOT

![screenshot of h-sploit](https://user-images.githubusercontent.com/67777622/137765984-375229d2-8ac9-4cf3-a7f7-56f9ef5632c7.png) 
 
## AVAILABLE ON :

* Termux

## TESTED ON :


* Termux

## REQUIREMENTS :
* internet 700 MB
* external storage permission
* storage 1Gb
* 1gb ram

## FEATURES :
* [+] Easy For Beginners
* [+] Just One Click To Install
* [+] Install Mestasploit
* [+] Repair Mestasploit
* [+] Restore Mestasploit
* [+] Delete Mestasploit
* [+] FIxed Ruby Issue

## My Accounts
* [YOUTUBE](https://www.youtube.com/c/TECHNOAGY)
* [TELEGRAM]()
* [FACEBOOK](https://www.facebook.com)
* [INSTAGRAM](https://www.instagram.com/het.hack/)
  
## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

