<h1 align="center">AutoXploit</h4>


<h4 align="center">Auto Payload Generator & Exploiter</h4>

<p align="center"><a href="https://imgbb.com/"><img src="https://i.ibb.co/HxCrkbG/Screenshot-from-2019-12-14-15-11-04.png" alt="Screenshot-from-2019-12-14-15-11-04" border="0"></a><br /><br />
</p>
AutoXploit is simply a shell sciript that helps you to generate metasploit payloads and starts the meterpreter handler quickly. At times, security researchers have to generate payloads and listen to the connection through handler constantly, AutoXploit not only allows you to quickly generate payloads but it also has an option to start the handler automatically. 

### Prerequisite
You should have a <b>linux</b> based system with <a href="https://github.com/rapid7/metasploit-framework/wiki/Nightly-Installers#installing-metasploit-on-linux--mac-os-x">metasploit-framework</a> installed. 

### Installation
Run `install.sh` as sudo and it will automatically install AutoXploit.
```
$ git clone https://github.com/Yashvendra/AutoXploit.git
$ cd AutoXploit
$ chmod +x install.sh
$ sudo ./install.sh
```

### Usage
Make sure you run this script as super user.
```
$ sudo autoxploit
```
### Gallery
<a href="https://ibb.co/L0jFdSY"><img src="https://i.ibb.co/NFDv2xt/Screenshot-from-2019-12-23-20-29-59.png" alt="Screenshot-from-2019-12-23-20-29-59" border="0"></a><br /><br />

### Upcoming Updates
Auxiliary scanners are on the way :) 

##### Note: This script is made for educational purposes and to help security researchers. Any actions or activities performed using this script is solely your responsibility.
