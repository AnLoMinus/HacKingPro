- ## 🔸 03 - Social Information
    - ## [googlehacking-tool](https://github.com/r9in/googlehacking-tool)
      >  ### Googlehacking tool for pentesters
      >  ![image](https://user-images.githubusercontent.com/51442719/174755900-c48bedf9-d8ea-4427-b894-90656eaed1e4.png)
    - ## [GooFuzz](https://github.com/m3n0sd0n4ld/GooFuzz) ~ GooFuzz - The Power of Google Dorks
        > GooFuzz is a tool to perform fuzzing with an OSINT approach, managing to enumerate directories, files, subdomains or parameters without leaving evidence on the target's server and by means of advanced Google searches (Google Dorking).
        > ![image](https://user-images.githubusercontent.com/51442719/174445711-01cd6280-591b-4272-bb83-bdaa185ae1ae.png)
    - [ ] [sherlock](https://github.com/sherlock-project/sherlock): 
      > 🔎 Hunt down social media accounts by username across social networks
    - [ ] [Anonphisher](https://github.com/TermuxHackz/anonphisher): 
      > Automated phishing tool made by AnonyminHack5 to phish various sites with 40+ templates and also has an inbuilt ngrok already to easily help you generate your link and send it to your victim. <br> Anonphisher tool is made with pure bash script and needs required packages for it to work.
    - ## [Namechk](https://github.com/GONZOsint/Namechk) Osint tool based on namechk.com for checking usernames on more than 100 websites, forums and social networks.
    - ![image](https://user-images.githubusercontent.com/51442719/174528824-9ec4d5d8-cb72-4cac-b94f-0c54d67faafc.png)
