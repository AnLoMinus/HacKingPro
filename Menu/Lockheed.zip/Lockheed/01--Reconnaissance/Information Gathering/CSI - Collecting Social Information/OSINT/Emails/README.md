- ## [SMWYG-Show-Me-What-You-Got](https://github.com/Viralmaniar/SMWYG-Show-Me-What-You-Got)
  > This tool allows you to perform OSINT and reconnaissance on an organisation or an individual. <br> 
  > It allows one to search 1.4 Billion clear text credentials which was dumped as part of BreachCompilation leak. <br>
  > This database makes finding passwords faster and easier than ever before.
  > ![image](https://user-images.githubusercontent.com/51442719/173315571-9671735c-c063-4a8d-93b6-375d55c21148.png)


