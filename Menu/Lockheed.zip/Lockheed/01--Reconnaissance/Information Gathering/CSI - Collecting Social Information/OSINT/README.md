## [Social Mapper](https://github.com/Greenwolf/social_mapper)
> ### A Social Media Enumeration & Correlation Tool by Jacob Wilkin(Greenwolf) 

## [Malfrat's OSINT Map](https://map.malfrats.industries/) 🗺 A map of OSINT tools.
  > ### Malfrat's OSINT Map is an online tree of selected useful tools made for OSINT purposes, made to help you during your investigations 👀
  > ![image](https://user-images.githubusercontent.com/51442719/174778659-0570444b-0222-4e69-aca9-73a2212bdcb2.png)

## [xeuledoc](https://github.com/Malfrats/xeuledoc) Fetch information about a public Google document.
  > ![](https://camo.githubusercontent.com/9331acf72942db276339fc0345deae4f4597058cb7c0d4e967cae0710278f46c/68747470733a2f2f66696c65732e636174626f782e6d6f652f6b35783361732e676966)


## [Geo-Recon](https://github.com/radioactivetobi/geo-recon) 
  > ### An OSINT CLI tool desgined to fast track IP Reputation and Geo-locaton look up for Security Analysts.

