- ## [uDork](https://github.com/m3n0sd0n4ld/uDork): 
  > uDork is a script written in Bash Scripting that uses advanced Google search techniques to obtain sensitive information in files or directories, find IoT devices, detect versions of web applications, and so on.
  - ## Menu
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/7.png)
  - ## Example of searching pdf files
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/8.png)
  - ## Example of a search for a list of default extensions.
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/12.png)
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/13.png)
  - ## Example of searching routes with the word "password"
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/9.png)
  - ## Dorks listing
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/10.png)
  - ## Example of use Dorks Massive 
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/11.png)
  - ## Example of use All Dorks Massive (Recommend for pentesting/audit) 
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/14.png)
    - ![Screenshot](https://github.com/m3n0sd0n4ld/uDork/blob/master/images/15.png)

- ## [SQL-Injection-Finder](https://github.com/j1t3sh/SQL-Injection-Finder): Automating the SQL Injection through Google dorks.
