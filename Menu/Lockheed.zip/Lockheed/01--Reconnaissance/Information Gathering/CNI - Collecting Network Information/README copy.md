- ## 🔸 02 - Networks Information
    - [ ] [nmap](https://github.com/nmap/nmap): 
        > Nmap - the Network Mapper. 
    - [ ] [Impacket](https://github.com/SecureAuthCorp/impacket): 
        > Impacket is a collection of Python classes for working with network protocols. <br> Impacket is focused on providing low-level programmatic access to the packets and for some protocols (e.g. SMB1-3 and MSRPC) the protocol implementation itself. <br> Packets can be constructed from scratch, as well as parsed from raw data, and the object-oriented API makes it simple to work with deep hierarchies of protocols. <br> The library provides a set of tools as examples of what can be done within the context of this library.

---

