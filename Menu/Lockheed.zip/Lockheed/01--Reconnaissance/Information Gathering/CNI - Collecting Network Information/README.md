# CNI - Collecting Network Information
