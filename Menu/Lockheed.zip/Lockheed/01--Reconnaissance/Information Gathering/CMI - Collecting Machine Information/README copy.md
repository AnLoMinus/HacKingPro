## 🔸 01 - Systems Information
  - [x] [Th3inspector](https://github.com/Moham3dRiahi/Th3inspector): 
      > Th3inspector 🕵️ best tool for Information Gathering 🔎 <br> ⭐ All in one tool for Information Gathering ⭐
  - [x] [theHarvester](https://github.com/laramies/theHarvester): 
      > theHarvester is a very simple to use, yet powerful and effective tool designed to be used in the early stages of a penetration test or red team engagement. <br> Use it for open source intelligence (OSINT) gathering to help determine a company's external threat landscape on the internet. <br> The tool gathers emails, names, subdomains, IPs and URLs using multiple public data sources that include:

#### OS Enumeration
- [htbenum](https://github.com/SolomonSklash/htbenum)
- [linux-smart-enumeration](https://github.com/diego-treitos/linux-smart-enumeration)
- [linenum](https://github.com/rebootuser/LinEnum)
- [enum4linux](https://github.com/portcullislabs/enum4linux)
- [ldapdomaindump](https://github.com/dirkjanm/ldapdomaindump)
- [PEASS - Privilege Escalation Awesome Scripts SUITE](https://github.com/carlospolop/privilege-escalation-awesome-scripts-suite)
- [Windows Exploit Suggester - Next Generation](https://github.com/bitsadmin/wesng)
- [smbmap](https://github.com/ShawnDEvans/smbmap)
- [pspy - unprivileged Linux process snooping](https://github.com/DominicBreuker/pspy)
- smbclient
