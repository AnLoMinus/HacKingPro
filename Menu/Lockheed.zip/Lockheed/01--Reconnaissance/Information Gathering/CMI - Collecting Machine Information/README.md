# CMI - Collecting Machine Information
