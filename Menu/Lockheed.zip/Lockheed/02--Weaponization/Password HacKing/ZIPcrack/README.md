
# ZIPcrack

![](screenshot.png)

**Brute Force - Password - ZIP**

![](/screenshot.png)

- <kbd>Use</kbd>

```cmd
root@kali:~# ZIPcrack /usr/share/wordlists/rockyou.txt file.zip
```

- <kbd>Download / Install</kbd>

```cmd
root@kali:~# wget -q "https://raw.githubusercontent.com/d4t4s3c/ZIPcrack/main/ZIPcrack.sh" -O /usr/bin/ZIPcrack
root@kali:~# chmod +x /usr/bin/ZIPcrack
```

---
