<img src="_media/logo.png" data-origin="_media/logo.png" alt="logo" height="300">

# HAITI

> _**HA**sh **I**den**T**if**I**er_

- 270+ hash types detected
- Hashcat and John the Ripper references
- CLI tool & library
- Hackable

[GitHub](https://github.com/Orange-Cyberdefense/haiti/)
[Get Started](pages/quick-start?id=quick-start)

![color](#ffffff)
