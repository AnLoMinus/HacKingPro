# HAITI

> _**HA**sh **I**den**T**if**I**er_

## What is it?

A CLI tool to identify the hash type of a given hash.

## Features

- 270+ hash types detected
- Hashcat and John the Ripper references
- CLI tool & library
- Hackable

## References

Homepage / Documentation: https://orange-cyberdefense.github.io/haiti/

## Author

Made by Alexandre ZANNI ([@noraj](https://github.com/noraj)), pentester from Orange Cyberdefense.
