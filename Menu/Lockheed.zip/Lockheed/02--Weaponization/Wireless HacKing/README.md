- # 🔸 06 - Wireless HacKing
- # 🔸 WiFi HacKing
  - ## [aircrack-ng](https://github.com/aircrack-ng/aircrack-ng)
    - ### [aircrack-ng]()
    - ### [airdecap-ng]()
    - ### [airmon-ng]()
    - ### [aireplay-ng]()
    - ### [airodump-ng]()
    - ### [airtun-ng]()
    - ### [packetforge-ng]()
    - ### [airbase-ng]()
    - ### [airdecloak-ng]()
    - ### [airolib-ng]()
    - ### [airserv-ng]()
    - ### [buddy-ng]()
    - ### [ivstools]()
    - ### [easside-ng]()
    - ### [tkiptun-ng]()
    - ### [wesside-ng]()
  - ## [FruityWifi](https://github.com/xtr4nge/FruityWifi)
  - ## [bettercap](https://github.com/bettercap/bettercap)
  - ## [WiFi-Pumpkin](https://github.com/P0cL4bs/WiFi-Pumpkin)
  - ## [Wifipumpkin3](https://github.com/P0cL4bs/wifipumpkin3)
  - ## [Airgeddon](https://github.com/v1s1t0r1sh3r3/airgeddon)
  - ## [Airbash](https://github.com/tehw0lf/airbash)
  - ## [WireSpy](https://github.com/aress31/wirespy)
  - ## [aircrack-ng-gui](https://github.com/t-gitt/aircrack-ng-gui)
  - ## [Websploit](https://github.com/f4rih/websploit)
  - ## [LazyAircrack](https://github.com/3xploitGuy/lazyaircrack)
  - ## [SniffAir](https://github.com/Tylous/SniffAir)
  - ## [Kismet](https://github.com/kismetwireless/kismet)
  - ## [AirStrike](https://github.com/redcode-labs/AirStrike)
  - ## [Wireless IDS](https://github.com/SYWorks/wireless-ids/)
  - ## [Fern Wifi Cracker](https://github.com/savio-code/fern-wifi-cracker)
  - ## [OWT](https://github.com/clu3bot/OWT)
  - ## [getAir2U](https://github.com/v1s1t0r999/getAir2U)
  - ## [BeaconGraph](https://github.com/daddycocoaman/BeaconGraph)
  - ## [Wifi-Hacker](https://github.com/esc0rtd3w/wifi-hacker)
  - ## [Wifite2](https://github.com/derv82/wifite2)
  - ## [Infernal-Wireless v3](https://github.com/entropy1337/infernal-twin)
  - ## [BoopSuite](https://github.com/MisterBianco/BoopSuite)
  - ## [NetAttack2](https://github.com/chrizator/netattack2)
  - ## [HT-WPS-Breaker](https://github.com/SilentGhostX/HT-WPS-Breaker)
  - ## [KisMac2](https://github.com/IGRSoft/KisMac2)
  - ## [LazyAirCrack](https://github.com/3xploitGuy/lazyaircrack)
  - ## [Piracy ⚓️](https://github.com/AnonymousAt3/piracy)
  - ## [WiCrackFi](https://github.com/ShineZex/WiCrackFi)
  - ## [EvilTwinFramework](https://github.com/Esser50K/EvilTwinFramework)
  - ## [Wifi-hacking](https://github.com/sajidhasan15/Wifi-hacking)
  - ## [hack-captive-portals](https://github.com/systematicat/hack-captive-portals)
  - ## [HacKingWiFi](https://github.com/Anlominus/HacKingWiFi)
  - ## [EAPHammer](https://github.com/s0lst1c3/eaphammer)
  - ## [RougeWifi](https://github.com/s0meguy1/RougeWifi)
  - ## [c41n](https://github.com/MS-WEB-BN/c41n/)

- ## [Wifi-Password](https://github.com/sdushantha/wifi-password)
    > Quickly fetch your WiFi password and if needed, generate a QR code of your WiFi to allow phones to easily connect.
    > - Works on macOS and Linux, Windows
    > - ![](https://github.com/sdushantha/wifi-password/raw/master/images/demo.gif)

  - ## [Wifi-Dumper](https://github.com/Viralmaniar/Wifi-Dumper) 
    > This is an open source tool to dump the wifi profiles and cleartext passwords of the connected access points on the Windows machine. <br>
    > This tool will help you in a Wifi penetration testing. <br>
    > Furthermore, it is useful while performing red team or an internal infrastructure engagements.
    > ![image](https://user-images.githubusercontent.com/51442719/173315962-5e4a883b-bfee-4c16-8d1a-75ab4c32f2fe.png)
  - ## [PwrDeauther](https://github.com/adamff24/PwrDeauther): ⚡ Deauth a specific WiFi access point or an entire channel
    > Automatic MDK3 deauther script. Fast, easy to use and powerful (MDK3 is more powerful than Aireplay). <br>
    > This script allows you to deauth a specific SSID (Option 1) or an entire channel (Option 2). <br>
    > ![](https://raw.githubusercontent.com/125K/PwrDeauther/master/img/1.png) <br>
    > ![](https://raw.githubusercontent.com/125K/PwrDeauther/master/img/2.png) <br>

- ## [Wifi-Cracker](https://github.com/trevatk/Wifi-Cracker) ~ For Android Devices


- # 🔸 Bluetooth HacKing
  - ## [RadareEye](https://github.com/souravbaghz/RadareEye): Tool for especially scanning nearby devices and execute a given command on its own system while the target device comes in range.
    > A tool for scanning nearby devices and execute command when the target device comes in between range.. <br>
    > ![image](https://user-images.githubusercontent.com/51442719/173346113-6a95f211-591a-4340-8136-278bb250a5e2.png) <br>
    > ![image](https://user-images.githubusercontent.com/51442719/173346154-ce750b45-52aa-43a7-be14-56a2bef1f8e1.png)





