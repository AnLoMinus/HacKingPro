# Mobile HacKing
## [MobileHackersWeapons](https://github.com/hahwul/MobileHackersWeapons)
  > Mobile Hacker's Weapons / A collection of cool tools used by Mobile hackers. Happy hacking , Happy bug-hunting
    - ![image](https://user-images.githubusercontent.com/51442719/173208602-1e97d9ef-8d01-4469-a269-1cfec44ecd71.png)
  
# 🔶 arm - Android HacKing
## [androidsploit](https://github.com/Hackeralok119/androidsploit): 
 > A tool for remote ADB exploitation in Python3.
## [L3MON](https://github.com/D3VL/L3MON)
## [AhMyth-Android-RAT](https://github.com/AhMyth/AhMyth-Android-RAT)
# 🔶 Cracking Android PIN and Pattern files
## [AndroidPINCrack](https://github.com/PentesterES/AndroidPINCrack) Bruteforce the Android Passcode given the hash and salt.
  > AndroidPINCrack is a Python script that bruteforce the Android Passcode given the hash and salt. <br>
  > Of course there are some other faster ways to crack than a python script, but it can be useful for numeric passcoders or wordlist attack. <br>
## [Android Pattern Lock Cracker](https://github.com/sch3m4/androidpatternlock) A little Python tool to crack the Pattern Lock on Android devices
## [Nyuki Android Lock Cracker](https://github.com/georgenicolaou/androidlockcracker) Python script for cracking and generating Android locks
## [Android-BruteForce](https://github.com/Gh005t/Android-BruteForce) Android BruteForce using ADB & Shell Scripting
  > Its is a simple shell script that brute force Android Lock screen (When USB DEBUGGING is enable) its uses ADB tools FOR BruteForce
## [ADBSploit](https://github.com/mesquidar/adbsploit)
  > A python based tool for exploiting and managing Android devices via ADB




