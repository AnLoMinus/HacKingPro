# Spy-Droid
Spy-Droid is an open source git tool using which we can keep eye in someone others android mobile phone
## Spy-Droid Framework . version 0.1
   Edited By: Shubham Kondekar
   
## Legal Disclamer:
   The author does not hold any responsibility for the bad use of this tool,
   remember this is only for educational purpose.

## Description:
   Spy-Droid is a framework that create & generate & embed apk payload to penetrate android platforms
 
## Screenshot:
![pic1](https://i.imgur.com/6kN9NtP.png)

![pic2](#Soon will Be uploaded")

<br /><br />

## Dependencies :
        
	1 - metasploit-framework
	2 - xterm
	3 - Zenity
	4 - Aapt
	5 - Apktool
	6 - Zipalign

## Download/Config/Usage:
   1) - Download the tool from github
         - git clone https://github.com/kondekarshubham123/Spy-Droid.git

   2) - Set script execution permission
         - cd Spy-Droid
         - chmod +x spy-droid


   3) - Run Drovo Framework :
        - ./spy-droid
